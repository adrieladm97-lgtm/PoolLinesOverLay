package com.example.poollines;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class OverlayService extends Service {
    private WindowManager wm;
    private WindowManager.LayoutParams imageParams, controlParams;
    private ImageView overlay;
    private float downX, downY;
    private int startX, startY;
    private float alpha = 0.72f;

    @Override public void onCreate() {
        super.onCreate();
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return; }
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);

        overlay = new ImageView(this);
        overlay.setImageResource(com.example.poollines.R.drawable.pool_overlay);
        overlay.setAlpha(alpha);
        overlay.setScaleType(ImageView.ScaleType.FIT_XY);

        imageParams = new WindowManager.LayoutParams(
                900, 510,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        imageParams.gravity = Gravity.TOP | Gravity.START;
        imageParams.x = 40; imageParams.y = 260;

        overlay.setOnTouchListener((v,e) -> {
            switch(e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    downX=e.getRawX(); downY=e.getRawY();
                    startX=imageParams.x; startY=imageParams.y; return true;
                case MotionEvent.ACTION_MOVE:
                    imageParams.x = startX + (int)(e.getRawX()-downX);
                    imageParams.y = startY + (int)(e.getRawY()-downY);
                    wm.updateViewLayout(overlay, imageParams); return true;
            }
            return true;
        });
        wm.addView(overlay, imageParams);

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setBackgroundColor(Color.argb(190, 20,20,20));

        TextView move = button("↕");
        TextView minus = button("−");
        TextView plus = button("+");
        TextView hide = button("×");

        move.setOnTouchListener((v,e) -> {
            switch(e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    downX=e.getRawX(); downY=e.getRawY();
                    startX=imageParams.x; startY=imageParams.y; return true;
                case MotionEvent.ACTION_MOVE:
                    imageParams.x = startX + (int)(e.getRawX()-downX);
                    imageParams.y = startY + (int)(e.getRawY()-downY);
                    controlParams.x=imageParams.x; controlParams.y=imageParams.y-90;
                    wm.updateViewLayout(overlay,imageParams);
                    wm.updateViewLayout(controls,controlParams); return true;
            }
            return true;
        });
        minus.setOnClickListener(v -> setAlpha(Math.max(.15f, alpha-.10f)));
        plus.setOnClickListener(v -> setAlpha(Math.min(1f, alpha+.10f)));
        hide.setOnClickListener(v -> stopSelf());

        controls.addView(move); controls.addView(minus); controls.addView(plus); controls.addView(hide);

        controlParams = new WindowManager.LayoutParams(
                220, 80,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        controlParams.gravity=Gravity.TOP|Gravity.START;
        controlParams.x=imageParams.x; controlParams.y=imageParams.y-90;
        wm.addView(controls, controlParams);
    }

    private TextView button(String s) {
        TextView t=new TextView(this); t.setText(s); t.setTextColor(Color.WHITE);
        t.setTextSize(28); t.setGravity(Gravity.CENTER); t.setPadding(16,0,16,0);
        return t;
    }
    private void setAlpha(float a) { alpha=a; overlay.setAlpha(alpha); }

    @Override public void onDestroy() {
        if (wm!=null) {
            try { if (overlay!=null) wm.removeView(overlay); } catch(Exception ignored){}
        }
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}