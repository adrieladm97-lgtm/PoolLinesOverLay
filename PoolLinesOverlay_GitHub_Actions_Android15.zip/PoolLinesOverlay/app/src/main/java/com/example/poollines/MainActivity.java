package com.example.poollines;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(40,40,40,40);

        TextView title = new TextView(this);
        title.setText("Pool Lines Overlay\nLinhas fixas em 360° — arrastável");
        title.setTextSize(22);
        box.addView(title);

        Button permission = new Button(this);
        permission.setText("1. Permitir aparecer sobre outros apps");
        permission.setOnClickListener(v -> {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(i);
        });
        box.addView(permission);

        Button start = new Button(this);
        start.setText("2. Iniciar overlay");
        start.setOnClickListener(v -> {
            if (Settings.canDrawOverlays(this))
                startService(new Intent(this, OverlayService.class));
        });
        box.addView(start);

        Button stop = new Button(this);
        stop.setText("Parar overlay");
        stop.setOnClickListener(v -> stopService(new Intent(this, OverlayService.class)));
        box.addView(stop);

        TextView info = new TextView(this);
        info.setText("\nDepois de iniciar, arraste o ícone ↕ para reposicionar. Use +/− para mudar a transparência.");
        box.addView(info);

        setContentView(box);
    }
}