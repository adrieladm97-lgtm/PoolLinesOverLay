# Compilar pelo celular com GitHub Actions

1. Crie um repositório novo no GitHub.
2. Pelo Chrome, abra o repositório e use **Add file > Upload files**.
3. Envie todo o conteúdo desta pasta, mantendo as pastas.
4. Confirme que `.github/workflows/build-apk.yml` foi enviado.
5. Abra **Actions**.
6. Toque em **Build APK** e depois **Run workflow**.
7. Espere terminar com o ícone verde.
8. Abra a execução concluída e procure **Artifacts**.
9. Baixe `PoolLinesOverlay-debug-apk.zip`, extraia e instale o APK.
10. No Android 15, permita **Aparecer sobre outros apps** para o aplicativo.

O workflow usa um runner hospedado pelo GitHub, Java 17 e Gradle 8.7. Ele gera um APK de debug e publica o APK como artifact.
