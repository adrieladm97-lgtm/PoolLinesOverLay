# Pool Lines Overlay — Android 15

Overlay transparente de referência para treino: mesa em proporção 2:1, linhas radiais a cada 5° (cobrindo 360°), mira central e marcações de caçapas/diamantes.

## Como compilar
1. Abra a pasta no Android Studio.
2. Use JDK 17 e Android SDK 35.
3. Sincronize o Gradle.
4. Gere o APK em Build > Build APK(s).
5. No Android 15, abra o app e permita "aparecer sobre outros apps".
6. Inicie o overlay e arraste o controle ↕ para posicionar.

Observação: é um overlay de referência visual. Ele não lê o jogo, não altera o APK do jogo e não calcula automaticamente a posição das bolas.
